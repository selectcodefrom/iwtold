<?php
$website_content = file_get_contents('http://www.php.net/source.php?url=/index.php');
echo $website_content;
?>