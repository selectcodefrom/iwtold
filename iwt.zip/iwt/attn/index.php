<?php
include('config.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Attendance System</title>
</head>
<body>
    <h1>QR Attendance System</h1>

    <?php
    // Fetch student data from the database
    $result = mysqli_query($conn, "SELECT * FROM students");
    
    while ($row = mysqli_fetch_assoc($result)) {
        $studentName = $row['student_name'];
        $qrCode = $row['qr_code'];

        // Generate QR code
        QRcode::png($qrCode, 'qrcodes/'.$qrCode.'.png', 'L', 4, 2);
        
        echo "<p>$studentName</p>";
        echo "<img src='qrcodes/$qrCode.png' alt='$studentName QR Code'>";
        echo "<hr>";
    }
    ?>

    <form action="process_attendance.php" method="post">
        <label for="qr_code">Scan QR Code:</label>
        <input type="text" name="qr_code" id="qr_code" required>
        <button type="submit">Submit Attendance</button>
    </form>
</body>
</html>
