<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qr_code = $_POST['qr_code'];

    $query = "UPDATE students SET attendance = 1 WHERE qr_code = '$qr_code'";
    mysqli_query($conn, $query);

    echo "Attendance recorded successfully!";
}
?>
