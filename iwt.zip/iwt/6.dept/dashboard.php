<?php
session_start();
//error_reporting(0);
include('config.php');
include('checklogin.php');
check_login();

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Student | Dashboard</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<link rel="stylesheet" href="style.css">
		

	</head>
	<body style="align-content: center;">
    <div style="padding-left: 2%;padding-top: 2%;background-color: bisque; padding-bottom: 2%;">
	<img style="margin-left: 470px;" src="img/r.png" width="350" height="70">
        <p style="font-size:28px; color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; " align="center">Department of Computer Science</p>
        <p style="font-size:28px; color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; " align="center">Student Dashboard</p>
    </div>
    
    <div style="padding-left: 2%;padding-top: 2%;background-color: whitesmoke; padding-bottom: 2%;text-align: justify;">
        <h1 style="font-size:28px;color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">Details</Details></h1>
    <p  style="font-size:18px; color: rgb(70, 5, 5);font-family: Arial, Helvetica, sans-serif;">
     
	<?php
	
$id=$_SESSION['id'];
$sql=mysqli_query($con,"select * from student where id  = '$id'");

while($row=mysqli_fetch_array($sql))
{
?>

											
<tr class="hidden-xs"><?php echo $row['name'];?>

												<tr><?php echo $row['reg'];?>
												<tr><?php echo $row['dob'];?>
												<tr><?php echo $row['mobile'];?>
												<tr><?php echo $row['email'];?>
												
											
											
											
											<?php 

											 
											}
											$_SESSION['id']=""?>

</p>
<a href="logout.php">
    <button>logout</button>
  </a> 
    </div>
    
            
            </div>
</body>
</html>

