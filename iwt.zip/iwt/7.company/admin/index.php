<?php
session_start();
error_reporting(0);
include("../config.php");
if(isset($_POST['submit']))
{
$ret=mysqli_query($con,"SELECT * FROM admin WHERE email='".$_POST['email']."' and password='".$_POST['password']."'");
$num=mysqli_fetch_array($ret);
if($num>0)
{

$extra="dashboard.php";
$_SESSION['admin']=$num['username'];
$_SESSION['aId']=$num['id'];
$host=$_SERVER['HTTP_HOST'];
$uip=$_SERVER['REMOTE_ADDR'];
$status=1;
// For stroing log if user login successfull

$uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
else
{
	// For stroing log if user login unsuccessfull
$_SESSION['login']=$_POST['register'];	
$uip=$_SERVER['REMOTE_ADDR'];
$status=0;

$_SESSION['errmsg']="Invalid username or password";
$extra="index.php";
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
header("location:http://$host$uri/$extra");
exit();
}
}
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<title>admin-Login</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<link rel="stylesheet" href="../style.css">
	</head>
	<body class="login">
		<div class="row">
		<div style="padding-left: 2%;padding-top: 2%;background-color: bisque; padding-bottom: 2%;">
		<img style="margin-left: 600px;" src="../img/r.png" width="100" height="100">
        
        <div class="topnav2" style="text-align: center;">
            <a  href="../index.html">Home</a>
            
          </div>
    </div>
	<div style="padding-left: 2%;padding-top: 2%;background-color: whitesmoke; padding-bottom: 2%;text-align: justify;">
        
			<div class="main-login">
				<div class="logo ">
				<a href="index.php"><h3 style="font-size:28px; color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; " align="center"> Admin Login</h3></a>
				</div>
				<div class="box-login">
					<form class="form-login " method="post">
						<fieldset>
							<legend>
								Sign in to your account
							</legend>
							<p>
								Please enter your Email and Password to log in.<br />
								<span style="color:red;"><?php echo $_SESSION['errmsg']; ?><?php echo $_SESSION['errmsg']="";?></span>
							</p>
							
							<div>
							</div>
							<div class="form-group">
								<span class="input-icon">
									<input type="email" class="form-control" name="email" placeholder=" Email" required>
									<i class="fa fa-envelope"></i> </span>
							</div>
							<br>
							<div class="form-group form-actions">
								<span class="input-icon">
									<input type="password" class="form-control password" name="password" placeholder=" Password" required>
									<br><br>
									<i class="fa fa-lock"></i>
									 </span>
																</div>
							<br>
							<div class="form-actions">
								
								<button type="submit" class="btn btn-primary pull-right" name="submit">
									Login <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
							<br>
							
							
						</fieldset>
					</form>
						<br>
					<div class="copyright">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase">PU</span>. <span>All rights reserved</span>
					</div>
			
				</div>

			</div>
		</div>
		
		<script>
			jQuery(document).ready(function() {
				Main.init();
				Login.init();
			});
		</script>
	
	</body>
	<!-- end: BODY -->
</html>