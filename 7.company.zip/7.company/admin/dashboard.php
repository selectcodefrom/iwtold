<?php
session_start();
//error_reporting(0);
include('config.php');
include('checklogin.php');
check_login_admin();
if(isset($_GET['del']))
		  {
		          mysqli_query($con,"delete from company where empId = '".$_GET['empId']."'");
                  $_SESSION['msg']="Data deleted !!";
		  }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Admin | Dashboard</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<link rel="stylesheet" href="../style.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
	</head>
	<body style="align-content: center;">
    <div style="padding-left: 2%;padding-top: 2%;background-color: bisque; padding-bottom: 2%;">
	<img style="margin-left: 600px;" src="../img/r.png" width="100" height="100">
        <p style="font-size:28px; color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; " align="center">Admin Dashboard</p>
    </div>
    
    <div style="padding-left: 2%;padding-top: 2%;background-color: whitesmoke; padding-bottom: 2%;text-align: justify;">
        <h1 style="font-size:28px;color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">Details</Details></h1>
    <p  style="font-size:18px; color: rgb(70, 5, 5);font-family: Arial, Helvetica, sans-serif;">
     
	<?php
	
$id=$_SESSION['aId'];
$sql=mysqli_query($con,"select * from admin where id  = '$id'");

while($row=mysqli_fetch_array($sql))
{
?>

											
<tr class="hidden-xs"><?php echo $row['username'];?>

												
<br>
												<tr><?php echo $row['mobile'];?><br>
												<tr><?php echo $row['email'];?>
												
											
											
											
											<?php 

											 
											}
											?>

</p>
<a href="logout.php">
    <button style="margin-left:10px;">logout</button>
  </a> 
    </div>
    
            
            </div>
			<div class="container-fluid container-fullw bg-white">
						

									<div class="row">
								<div class="col-md-15">
									
								<p style="color:green;"><h4 style="color:green;"><?php echo htmlentities($_SESSION['msg']);?></h4>
								<?php echo htmlentities($_SESSION['msg']=" ");?></p>	
									<table class="table table-hover" id="sample-table-1">
										<thead>
											<tr>
												<th class="center">S.N</th>
												<th>Full Name</th>
												<th>Employee ID</th>
												<th>Mobile</th>
												<th>Email</th>
												<th>Message</th>
												<th>Action</th>
												
											</tr>
										</thead>
										<tbody>
<?php

$sql=mysqli_query($con,"select * from company");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>

											<tr>
												<td class="center"><?php echo $cnt;?>.</td>
												<td class="hidden-xs"><?php echo $row['name'];?></td>
												<td><?php echo $row['empId'];?></td>
												<td><?php echo $row['mobile'];?></td>
												<td><?php echo $row['email'];?>	</td>
												<td><?php echo $row['message'];?></td>
												<td ><div class="">							
													
	<a href="edit-employee.php?empId=<?php echo $row['empId']?>&edit=edit" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Plus"><i class="fa fa-edit" style="font-size:24px" ></i></a>
												
					
													
	<a href="dashboard.php?empId=<?php echo $row['empId']?>&del=delete" onClick="return confirm('Are you sure you want to delete?')"class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove"><i class="fa fa-times fa fa-white" style="font-size:24px"></i></a>
												</div>
												
												</td>
											</tr>
											
											<?php 
$cnt=$cnt+1;
											 }?>
											
											
										</tbody>
									</table>
								</div>
							</div>
								</div>
							</div>
						</div>
</body>
</html>

