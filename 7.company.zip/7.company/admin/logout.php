<?php
session_start();
$_SESSION['admin']=="";
$_SESSION['errmsg']="You have successfully logout";
?>
<script language="javascript">
document.location="index.php";
</script>
