<?php
include('config.php');
session_start();
$unique_id = $_SESSION['unique_id'];

$sql = "SELECT attendance_records.*, students.student_name 
FROM attendance_records
INNER JOIN students ON attendance_records.reg = students.reg
WHERE attendance_records.unique_id = '$unique_id'
ORDER BY attendance_records.reg ASC";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Records</title>
    <!-- Add jQuery library -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        $(document).ready(function () {
            // Function to load and update attendance records
            function loadAttendanceRecords() {
                $.ajax({
                    url: 'get_attendance_records.php', // Create a new PHP file to handle AJAX requests
                    type: 'GET',
                    success: function (data) {
                        $('#attendance-list').html(data);
                    },
                    error: function () {
                        console.error('Error fetching attendance records.');
                    }
                });
            }

            // Load attendance records initially
            loadAttendanceRecords();

            // Periodically update attendance records (every 10 seconds in this example)
            setInterval(function () {
                loadAttendanceRecords();
            }, 1000);
        });
    </script>
</head>
<body>
    <h1>Live Attendance Records</h1>
    <ul id="attendance-list">
        <?php
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                echo '<li>' . $row['reg'] . ' - ' . $row['attendance_time'] . '</li>';
            }
        } else {
            echo '<li>No attendance records yet.</li>';
        }
        ?>
    </ul>
</body>
</html>
