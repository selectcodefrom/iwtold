<?php
include('phpqrcode/qrlib.php');
include('config.php');
session_start();

// Check if form is submitted
if (isset($_GET['staff_id'])) {
    // Get staff name and generate a unique QR code
    $staff_id = $_GET['staff_id'];
    $server_ip = getHostByName(getHostName());

    // Check if a unique_id is already set in the session
    if (empty($_SESSION['unique_id'])) {
        // If not, generate a new unique_id
        $unique_id = time() . mt_rand(1000, 9999);
        $_SESSION['unique_id'] = $unique_id;  // Save it in the session
    } else {
        // If it's already set, use the existing unique_id
        $unique_id = $_SESSION['unique_id'];
    }

    $qr_code = "http://$server_ip/iwt/att2/mark_attendance.php?mark=true&unique_id=" . $unique_id;

    // Generate QR code and save it as an image
    QRcode::png($qr_code, "qrcodes/$unique_id.png");

    $sql = "INSERT INTO uni (staff_id, unique_id) VALUES ('$staff_id', '$unique_id')";
    $conn->query($sql);
}

if (isset($_GET['destroy'])) {
    // Delete the file named $_SESSION['unique_id']
    $file_to_delete = "qrcodes/" . $_SESSION['unique_id'] . ".png";
    
    // Check if the file exists before attempting to delete
    if (file_exists($file_to_delete)) {
        unlink($file_to_delete); // Delete the file
    }

    // Destroy the session
    session_destroy();
    header("Location: index.php");
exit();
}

// Display the generated QR code
echo '<img src="qrcodes/' . $unique_id . '.png" width="500" height="500">';
echo '<br><a href="generate_qr.php?destroy=true"><button type="submit">END</button></a>';

include('view_attendance.php');
?>
