<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Index</title>
</head>
<body>
    <h1>Staff Index</h1>
    
    <hr>

    <!-- Display a list of staff members with Generate QR button -->
    <?php
    // Include your database connection logic here

    include('config.php');

    $sql = "SELECT * FROM staff";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>Staff Members:</h2>";
        echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li>{$row['staff_name']} - {$row['staff_id']} - {$row['position']} ";
            echo "<a href='generate_qr.php?staff_id={$row['staff_id']}' target='self'>Generate QR Code</a></li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No staff members found.</p>";
    }

    
    ?>
</body>
</html>
