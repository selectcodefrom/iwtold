<?php
include('config.php');
session_start();
$unique_id = $_SESSION['unique_id'];

$sql = "SELECT attendance_records.*, students.student_name 
        FROM attendance_records
        INNER JOIN students ON attendance_records.reg = students.reg
        WHERE attendance_records.unique_id = '$unique_id'
        ORDER BY attendance_records.reg ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $counter = 1; // Initialize a counter variable
    while ($row = $result->fetch_assoc()) {
        echo '<li>' . $counter .  '. ' . $row['student_name'] .'    ' . $row['reg'] . ' - ' . $row['attendance_time'] . '</li>';
        $counter++; // Increment the counter for the next iteration
    }
 } else {
    echo '<li>No attendance records yet.</li>';
}

$conn->close();
?>
