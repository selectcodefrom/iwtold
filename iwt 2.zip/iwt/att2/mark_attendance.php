<?php
include('config.php');
// Check if the QR code is scanned
$unique_id = '';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['mark'])) {
    $unique_id = $_GET['unique_id'];
}

if (isset($_POST['submit'])) {
    $reg = $_POST['reg'];
    
    $unique_id=$_POST['unique_id'];
    $sql = "INSERT INTO attendance_records (unique_id, reg) VALUES ('$unique_id', '$reg')";
    $conn->query($sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>
</head>
<body>
    <h1>Mark Attendance</h1>
    <p>Scan the student's QR code to mark attendance.</p>
    <form action="mark_attendance.php?mark=true&unique_id=<?php echo $unique_id; ?>" method="post">
        <!-- Add a hidden input to carry the unique_id -->
        <input type="hidden" name="unique_id" value="<?php echo $unique_id; ?>">
        <label for="reg">QR Code:</label>
        <input type="text" id="reg" name="reg" required>
        <button type="submit" name="submit">Mark Attendance</button>
    </form>
</body>
</html>
