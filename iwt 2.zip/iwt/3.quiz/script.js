const Questions = [
	{
	  q: "What is capital of India?",
	  a: [
		{ text: "Gandhinagar", isCorrect: false },
		{ text: "Surat", isCorrect: false },
		{ text: "Delhi", isCorrect: true },
		{ text: "Mumbai", isCorrect: false }
	  ]
	},
	{
	  q: "What is the capital of Thailand?",
	  a: [
		{ text: "Lampang", isCorrect: false, isSelected: false },
		{ text: "Phuket", isCorrect: false },
		{ text: "Ayutthaya", isCorrect: false },
		{ text: "Bangkok", isCorrect: true }
	  ]
	},
	{
	  q: "What is the capital of Gujarat?",
	  a: [
		{ text: "Surat", isCorrect: false },
		{ text: "Vadodara", isCorrect: false },
		{ text: "Gandhinagar", isCorrect: true },
		{ text: "Rajkot", isCorrect: false }
	  ]
	},
	{
	  q: "What is the capital of France?",
	  a: [
		{ text: "Paris", isCorrect: true },
		{ text: "London", isCorrect: false },
		{ text: "Madrid", isCorrect: false },
		{ text: "Berlin", isCorrect: false }
	  ]
	},
	{
	  q: "Who wrote the play 'Romeo and Juliet'?",
	  a: [
		{ text: "William Shakespeare", isCorrect: true },
		{ text: "Charles Dickens", isCorrect: false },
		{ text: "Jane Austen", isCorrect: false },
		{ text: "Leo Tolstoy", isCorrect: false }
	  ]
	},
	{
	  q: "What is the largest planet in our solar system?",
	  a: [
		{ text: "Mars", isCorrect: false },
		{ text: "Venus", isCorrect: false },
		{ text: "Saturn", isCorrect: false },
		{ text: "Jupiter", isCorrect: true }
	  ]
	},
	{
	  q: "Which country is known as the Land of the Rising Sun?",
	  a: [
		{ text: "Thailand", isCorrect: false },
		{ text: "Japan", isCorrect: true },
		{ text: "China", isCorrect: false },
		{ text: "South Korea", isCorrect: false }
	  ]
	},
	
	{
	  q: "What is the tallest mountain in the world?",
	  a: [
		{ text: "K2", isCorrect: false },
		{ text: "Mount Kilimanjaro", isCorrect: false },
		{ text: "Mount Everest", isCorrect: true },
		{ text: "Matterhorn", isCorrect: false }
	  ]
	},
	{
	  q: "Who is the author of the Harry Potter book series?",
	  a: [
		{ text: "J.R.R. Tolkien", isCorrect: false },
		{ text: "George Orwell", isCorrect: false },
		{ text: "J.K. Rowling", isCorrect: true },
		{ text: "Stephen King", isCorrect: false }
	  ]
	},
	{
	  q: "What is the chemical symbol for gold?",
	  a: [
		{ text: "Go", isCorrect: false },
		{ text: "Gd", isCorrect: false },
		{ text: "Au", isCorrect: true },
		{ text: "Ag", isCorrect: false }
	  ]
	},
	{
	  q: "Which gas do plants absorb from the atmosphere during photosynthesis?",
	  a: [
		{ text: "Oxygen", isCorrect: false },
		{ text: "Carbon dioxide", isCorrect: true },
		{ text: "Nitrogen", isCorrect: false },
		{ text: "Methane", isCorrect: false }
	  ]
	},
	{
	  q: "What is the currency of Germany?",
	  a: [
		{ text: "Euro", isCorrect: true },
		{ text: "Pound Sterling", isCorrect: false },
		{ text: "Dollar", isCorrect: false },
		{ text: "Yen", isCorrect: false }
	  ]
	},
	
	{
	  q: "In which year did Christopher Columbus first reach the Americas?",
	  a: [
		{ text: "1492", isCorrect: true },
		{ text: "1507", isCorrect: false },
		{ text: "1519", isCorrect: false },
		{ text: "1534", isCorrect: false }
	  ]
	},
	{
	  q: "What is the largest organ in the human body?",
	  a: [
		{ text: "Brain", isCorrect: false },
		{ text: "Liver", isCorrect: false },
		{ text: "Heart", isCorrect: false },
		{ text: "Skin", isCorrect: true }
	  ]
	},
	{
	  q: "Which planet is known as the Red Planet?",
	  a: [
		{ text: "Mars", isCorrect: true },
		{ text: "Venus", isCorrect: false },
		{ text: "Jupiter", isCorrect: false },
		{ text: "Saturn", isCorrect: false }
	  ]
	},
	{
	  q: "Who painted the Sistine Chapel ceiling?",
	  a: [
		{ text: "Leonardo da Vinci", isCorrect: false },
		{ text: "Michelangelo", isCorrect: true },
		{ text: "Raphael", isCorrect: false },
		{ text: "Donatello", isCorrect: false }
	  ]
	},
	
	{
	  q: "Who is the current President of the United States? (As of my last knowledge update in September 2021)",
	  a: [
		{ text: "Joe Biden", isCorrect: true },
		{ text: "Donald Trump", isCorrect: false },
		{ text: "Barack Obama", isCorrect: false },
		{ text: "George W. Bush", isCorrect: false }
	  ]
	},
	{
	  q: "Which gas makes up the majority of Earth's atmosphere?",
	  a: [
		{ text: "Oxygen", isCorrect: false },
		{ text: "Carbon dioxide", isCorrect: false },
		{ text: "Nitrogen", isCorrect: true },
		{ text: "Hydrogen", isCorrect: false }
	  ]
	},
	{
	  q: "What is the longest river in the world?",
	  a: [
		{ text: "Amazon River", isCorrect: false },
		{ text: "Nile River", isCorrect: true },
		{ text: "Yangtze River", isCorrect: false },
		{ text: "Mississippi River", isCorrect: false }
	  ]
	},
	{
	  q: "Who is known as the Father of Modern Physics?",
	  a: [
		{ text: "Isaac Newton", isCorrect: false },
		{ text: "Niels Bohr", isCorrect: false },
		{ text: "Albert Einstein", isCorrect: true },
		{ text: "Stephen Hawking", isCorrect: false }
	  ]
	},
	
  ];
  
   

let currQuestion = 0
let score = 0

function loadQues() {
	const question = document.getElementById("ques")
	const opt = document.getElementById("opt")

	question.textContent = Questions[currQuestion].q;
	opt.innerHTML = ""

	for (let i = 0; i < Questions[currQuestion].a.length; i++) {
		const choicesdiv = document.createElement("div");
		const choice = document.createElement("input");
		const choiceLabel = document.createElement("label");

		choice.type = "radio";
		choice.name = "answer";
		choice.value = i;

		choiceLabel.textContent = Questions[currQuestion].a[i].text;

		choicesdiv.appendChild(choice);
		choicesdiv.appendChild(choiceLabel);
		opt.appendChild(choicesdiv);
	}
}

loadQues();

function loadScore() {
	const totalScore = document.getElementById("score")
	totalScore.innerHTML = `You scored ${score} out of ${Questions.length} <br><a href="index.html"><button>Re-Try</button></a>`
}



function nextQuestion() {
	if (currQuestion < Questions.length - 1) {
		currQuestion++;
		loadQues();
	} else {
		document.getElementById("opt").remove()
		document.getElementById("ques").remove()
		document.getElementById("btn").remove()
		loadScore();
	}
}

function checkAns() {
	const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

	if (Questions[currQuestion].a[selectedAns].isCorrect) {
		score++;
		console.log("Correct")
		nextQuestion();
	} else {
		nextQuestion();
	}
}
