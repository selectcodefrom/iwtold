<?php
session_start();
//error_reporting(0);
include('config.php');
include('checklogin.php');
check_login();

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Student | Dashboard</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<link rel="stylesheet" href="style.css">
		

	</head>
	<body style="align-content: center;">
    <div style="padding-left: 2%;padding-top: 2%;background-color: bisque; padding-bottom: 2%;">
	<img style="margin-left: 600px;" src="img/r.png" width="100" height="100">
        <p style="font-size:28px; color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; " align="center">Employee Dashboard</p>
    </div>
    
    <div style="padding-left: 2%;padding-top: 2%;background-color: whitesmoke; padding-bottom: 2%;text-align: justify;">
        <h1 style="font-size:28px;color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">Details</h1>
    <p  style="font-size:18px; color: rgb(70, 5, 5);font-family: Arial, Helvetica, sans-serif;">
     
	<?php
	
$id=$_SESSION['id'];
$sql=mysqli_query($con,"select * from company where id  = '$id'");

while($row=mysqli_fetch_array($sql))
{
?>

<label>Nmae:</label>										
<tr class="hidden-xs"><?php echo $row['name'];?>
<br>										 	<label>employeeId:</label>
												<tr><?php echo $row['empId'];?><br>
												<label>DOB:</label>
												<tr><?php echo $row['dob'];?><br>
												<label>Mobile:</label>
												<tr><?php echo $row['mobile'];?><br>
												<label>Email:</label>
												<tr><?php echo $row['email'];?><br>
												<label>Message:</label>
												<tr><?php echo $row['message'];?><br>
											
											
											
											<?php 

											 
											}
											?>

</p>
<a href="logout.php" >
    <button  style="margin-left:10px;">logout</button>
  </a> 
    </div>
    
            
            </div>
</body>
</html>

