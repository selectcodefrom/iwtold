<?php
include_once('config.php');
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$regNo=$_POST['reg'];
$dob=$_POST['dob'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$password=$_POST['password'];
$query=mysqli_query($con,"insert into student(name,reg,dob,mobile,email,password) values('$name','$regNo','$dob','$mobile','$email','$password')");
if($query)
{
	echo "<script>alert('Successfully Registred.');</script>";
	//header('location:index.php');
}
else {
echo "<script>alert('Registration unsuccessfully');</script>";
}
}
?>


<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Student-Registration</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<link rel="stylesheet" href="style.css">
		
		<script type="text/javascript">
function valid()
{
 if(document.registration.password.value!= document.registration.password_again.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.registration.password_again.focus();
return false;
}
return true;
}
</script>
	</head>
	<body class="login">
		<div class="row">
		<div style="padding-left: 2%;padding-top: 2%;background-color: bisque; padding-bottom: 2%;">
		<img style="margin-left: 470px;" src="img/r.png" width="350" height="70">
        <p style="font-size:28px; color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; " align="center">Department of Computer Science</p>
        <div class="topnav">
            <a  href="index.html">Home</a>
            <a class="active"href="user-login.php">Login</a>
            <a href="contact.html">Contact</a>
            <a href="about.html">About</a>
          </div>
    </div>
	<div style="padding-left: 2%;padding-top: 2%;background-color: whitesmoke; padding-bottom: 2%;text-align: justify;">
        
			<div class="main-login">
				<div class="logo ">
				<a href="index.php"><h3 style="font-size:28px; color: brown;font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; " align="center">  Student registration</h3></a>
				</div>
				<div class="box-login">
					<form class="form-login " method="post">
						<fieldset>
							<legend>
								Sign in to your account
							</legend>
							<p>
								Please enter your Email and Password to log in.<br />
								<span style="color:red;"></span>
							</p>
							
							<div>
							</div>

							<div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" name="name" placeholder=" Full Name" required>
									<i class="fa fa-user"></i> </span>
							</div>
								<br>
							<div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" name="reg" placeholder=" Register No." required>
									<i class="fa fa-user"></i> </span>
							</div>
							<br>
							<div class="form-group">
								<span class="input-icon">
									<input type="date" class="form-control" name="dob" placeholder=" Date of Birth" required>
									<i class="fa fa-date"></i> </span>
							</div>
							<br>
							<div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" name="mobile" placeholder="Mobile" required>
									<i class="fa fa-date"></i> </span>
							</div>
							<br>
							<div class="form-group">
								<span class="input-icon">
									<input type="email" class="form-control" name="email" placeholder=" Email" required>
									<i class="fa fa-envelope"></i> </span>
							</div>
							<br>
							<div class="form-group">
								<span class="input-icon">
									<input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
									<i class="fa fa-lock"></i> </span>
							</div>
							<br>
							<div class="form-group">
								<span class="input-icon">
									<input type="password" class="form-control"  id="password_again" name="password_again" placeholder="Password Again" required>
									<i class="fa fa-lock"></i> </span>
							</div>
							<br>
							<div class="form-actions">
								
								<button type="submit" class="btn btn-primary pull-right" name="submit">
									submit <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
							<br>
							<div class="new-account">
								You already have an account?
								<a href="user-login.php">
								<br>
									Signin
								</a>
							</div>
							
						</fieldset>
					</form>
						<br>
					<div class="copyright">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase">PU</span>. <span>All rights reserved</span>
					</div>
			
				</div>

			</div>
		</div>
		
		<script>
			jQuery(document).ready(function() {
				Main.init();
				Login.init();
			});
		</script>
	
	</body>
	<!-- end: BODY -->
</html>