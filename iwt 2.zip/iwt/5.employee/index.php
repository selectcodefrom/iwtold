<?php
include_once('config.php');
$lang1='';
$lang2='';
$lang3='';
if(isset($_POST['submit']))
{

$name=$_POST['name'];
$gender=$_POST['gender'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$address=$_POST['address'];
$dept=$_POST['dept'];
$position=$_POST['position'];
$salary=$_POST['salary'];
$exp=$_POST['exp'];
$lang1=$_POST['lang1'];
$lang2=$_POST['lang2'];
$lang3=$_POST['lang3'];

$lang=$lang1.', '.$lang2.', '.$lang3;

$query=mysqli_query($con,"insert into employee(name,gender,phone,email,address,dept,position,salary,exp,lang) values('$name','$gender','$phone','$email','$address','$dept','$position','$salary','$exp','$lang')");
if($query)
{
	echo "<script>alert('Successfully inserted...');</script>";
	//header('location:index.php');
}
else {
echo "<script>alert('request unsuccessfully');</script>";
}
}
?>


<!DOCTYPE html>
<html lang="en">

	<head>
		<title>Emplyee Registration</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		
		

		<link rel="stylesheet" href="styles.css">

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		

	</head>

	<body class="login">
		<!-- start: REGISTRATION -->
		<div class="row">
			<div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
				<div class="logo margin-top-30">
				<a href="index.php"><h2>IWT | Employee Registration</h2></a>
				</div>
				<!-- start: REGISTER BOX -->
				<div class="box-register">
					<form name="index" id="index"  method="post" >
						<fieldset>
							<legend>
								Enter Employee details below:
							</legend>
							
							<!-- Modify the Full Name input -->
<div class="form-group">
    <i class="fa fa-user"></i>
    <input type="text" class="form-control" name="name" placeholder="Full Name" required>
</div>

<!-- Modify the Gender input -->
<div class="form-group">
    <label class="block">
        Gender
    </label>
    <div class="clip-radio radio-primary">
        <i class="fa fa-male"></i>
        <input type="radio" id="rg-male" name="gender" value="male">
        <label for="rg-male">
            Male
        </label>
        <i class="fa fa-female"></i>
        <input type="radio" id="rg-female" name="gender" value="female" >
        <label for="rg-female">
            Female
        </label>
        <i class="fa fa-genderless"></i>
        <input type="radio" id="rg-other" name="gender" value="other">
        <label for="rg-other">
            Others
        </label>
    </div>
</div>

<!-- Modify the Phone Number input -->
<div class="form-group">
    <i class="fa fa-phone"></i>
    <input type="text" class="form-control" name="phone" placeholder="Phone no." required>
</div>

<!-- Modify the Email input -->
<div class="form-group">
    <i class="fa fa-envelope"></i>
    <input type="email" class="form-control" name="email" placeholder="Email Id" required>
</div>

<!-- Modify the Address input -->
<div class="form-group">
    <i class="fa fa-address-book"></i>
	<input type="text" class="form-control" name="address" placeholder="Address" required>
    
</div>

<!-- Modify the Department input -->
<div class="form-group">
    <i class="fa fa-building"></i>

<select class="form-control" name="dept" >
  
  <option value="Engineering">Engineering</option>
  <option value="marketing">Marketing</option>
  <option value="Planning">Planning</option>
  <option value="sales">Sales</option>
</select>
</div>

<!-- Modify the Job Position input -->
<div class="form-group">
    <i class="fa fa-briefcase"></i>
    <select class="form-control" name="position" >
  
  <option value="HR">HR</option>
  <option value="Engineer">Engineer</option>
  <option value="Supervisor">Planning</option>
  <option value="Sales Executive">Sales</option>
</select>
</div>

<!-- Modify the Salary input -->
<div class="form-group">
    <i class="fa fa-money"></i>
    <input type="text" class="form-control" name="salary" placeholder="Salary" required>
</div>
<div class="form-group">

    <input type="number" class="form-control" name="exp" placeholder="Year of Expreance" min="1" max="10"required>
</div>
<div class="form-group">
<label class="block">
        Languages
    </label>
	<br>
<input type="checkbox" id="lang1" name="lang1" value="English">
<label for="vehicle1">English</label><br>
<input type="checkbox" id="lang2" name="lang2" value="French">
<label for="vehicle2">French</label><br>
<input type="checkbox" id="lang3" name="lang3" value="German">
<label for="vehicle3">German</label><br>
    
</div>
							
							<div class="form-actions">
								
								<button type="submit" class="btn btn-primary pull-right" id="submit" name="submit">
									Submit <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
						</fieldset>
					</form>

					<div class="copyright">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> IWT</span>| <span>All rights reserved</span>
					</div>

				</div>

			</div>
		</div>
		
		
		
	</body>
	<!-- end: BODY -->
</html>